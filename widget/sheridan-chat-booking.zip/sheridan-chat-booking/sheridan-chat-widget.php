<?php
/**
 * Plugin Name: Sheridan Rentals Chat & Booking
 * Description: Embeds the Sheridan Rentals AI chatbot and booking enhancements on your WordPress site.
 * Version: 2.0.0
 * Author: Sheridan Rentals
 */

if (!defined('ABSPATH')) exit;

// Settings page
add_action('admin_menu', function() {
    add_options_page(
        'Sheridan Rentals Chat',
        'SR Chat Widget',
        'manage_options',
        'sr-chat-widget',
        'sr_chat_settings_page'
    );
});

add_action('admin_init', function() {
    register_setting('sr_chat_settings', 'sr_chat_server_url');
    register_setting('sr_chat_settings', 'sr_chat_enabled');
});

function sr_chat_settings_page() {
    ?>
    <div class="wrap">
        <h1>Sheridan Rentals Chat & Booking</h1>
        <form method="post" action="options.php">
            <?php settings_fields('sr_chat_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Chat Server URL</th>
                    <td>
                        <input type="url" name="sr_chat_server_url" value="<?php echo esc_attr(get_option('sr_chat_server_url', 'https://chat.sheridantrailerrentals.us')); ?>" class="regular-text" placeholder="https://chat.sheridantrailerrentals.us">
                        <p class="description">The URL where the NanoClaw chat server is running</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Enable Chat Widget</th>
                    <td>
                        <label>
                            <input type="checkbox" name="sr_chat_enabled" value="1" <?php checked(get_option('sr_chat_enabled', '1'), '1'); ?>>
                            Show chat widget on all pages
                        </label>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Embed the chat widget on the frontend
add_action('wp_footer', function() {
    if (get_option('sr_chat_enabled', '1') !== '1') return;

    $server_url = esc_url(get_option('sr_chat_server_url', 'https://chat.sheridantrailerrentals.us'));
    if (empty($server_url)) return;

    // Chat widget on all pages
    echo '<script src="' . $server_url . '/widget/chat-widget.js" data-server="' . $server_url . '"></script>';

    // Booking enhancer on form pages only
    if (is_page('form') || strpos($_SERVER['REQUEST_URI'], '/form') !== false) {
        echo '<script src="' . $server_url . '/widget/booking-enhancer.js" data-server="' . $server_url . '"></script>';
    }
});
